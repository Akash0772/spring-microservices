package com.akash.msapp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(MsApp2Application.class, args);
	}

}
